### Welcome to the Evothings IoT App Gallery repository!

The gallery items are currently stored in gallery.json. The following JSON structure serves as an example:

	{
		"items": [
			{
				"description": "Raspberry Car",
				"author": "Evothings",
				"image": "http://evomedia.evothings.com/gallery/raspberry-car/app_screenshot.png",
				"url": "http://evomedia.evothings.com/gallery/raspberry-car/",
				"links": {
					"YouTube": "https://www.youtube.com/watch?v=rAHd6haIOQE",
					"Article": "http://evothings.com/controlling-a-toy-car-with-evothings-and-raspberry-pi/",
					"Custom link": "http://yoursite.com/"
				},
				"tags": "example"
			}
		]
	}